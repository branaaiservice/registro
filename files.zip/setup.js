// POST (equipo): prepara la pestaña de Google Sheets (encabezados, anchos, altura de filas para imágenes, lista de estados).
import { handler, HttpError, requireAuth, sheets, rng, TAB, HEAD, ESTADOS } from './_lib.js';

export default handler(async (req, res) => {
  if (req.method !== 'POST') throw new HttpError(405, 'Método no permitido');
  requireAuth(req);

  const meta = await sheets('?fields=sheets.properties');
  let sh = (meta.sheets || []).find(s => s.properties.title === TAB);
  if (!sh) {
    const r = await sheets(':batchUpdate', { method: 'POST', body: { requests: [{ addSheet: { properties: { title: TAB } } }] } });
    sh = { properties: r.replies[0].addSheet.properties };
  }
  const id = sh.properties.sheetId;
  const ROWS = 5000;

  await sheets(`/values/${rng('A1:P1')}?valueInputOption=RAW`, { method: 'PUT', body: { values: [HEAD] } });

  const col = (a, b, px) => ({ updateDimensionProperties: { range: { sheetId: id, dimension: 'COLUMNS', startIndex: a, endIndex: b }, properties: { pixelSize: px }, fields: 'pixelSize' } });
  await sheets(':batchUpdate', { method: 'POST', body: { requests: [
    { updateSheetProperties: { properties: { sheetId: id, gridProperties: { rowCount: ROWS, columnCount: 16, frozenRowCount: 1 } }, fields: 'gridProperties(rowCount,columnCount,frozenRowCount)' } },
    { repeatCell: { range: { sheetId: id, startRowIndex: 0, endRowIndex: 1 }, cell: { userEnteredFormat: { textFormat: { bold: true, foregroundColor: { red: 1, green: 1, blue: 1 } }, backgroundColor: { red: .15, green: .15, blue: .15 }, horizontalAlignment: 'CENTER' } }, fields: 'userEnteredFormat(textFormat,backgroundColor,horizontalAlignment)' } },
    col(0, 1, 70), col(1, 2, 140), col(2, 3, 110), col(3, 4, 200), col(4, 6, 110), col(6, 7, 120), col(7, 8, 320), col(8, 9, 200), col(9, 10, 240), col(10, 11, 140), col(11, 12, 220), col(12, 13, 330), col(13, 14, 90),
    { updateDimensionProperties: { range: { sheetId: id, dimension: 'ROWS', startIndex: 1, endIndex: ROWS }, properties: { pixelSize: 170 }, fields: 'pixelSize' } },
    { repeatCell: { range: { sheetId: id, startRowIndex: 1, endRowIndex: ROWS, startColumnIndex: 0, endColumnIndex: 14 }, cell: { userEnteredFormat: { verticalAlignment: 'MIDDLE', wrapStrategy: 'WRAP' } }, fields: 'userEnteredFormat(verticalAlignment,wrapStrategy)' } },
    { setDataValidation: { range: { sheetId: id, startRowIndex: 1, endRowIndex: ROWS, startColumnIndex: 2, endColumnIndex: 3 }, rule: { condition: { type: 'ONE_OF_LIST', values: ESTADOS.map(v => ({ userEnteredValue: v })) }, showCustomUi: true, strict: false } } },
    { updateDimensionProperties: { range: { sheetId: id, dimension: 'COLUMNS', startIndex: 14, endIndex: 16 }, properties: { hiddenByUser: true }, fields: 'hiddenByUser' } }
  ] } });
  res.json({ ok: true });
});
