// Utilidades compartidas: Google Sheets (sin dependencias), sesiones y subida de imágenes.
import crypto from 'node:crypto';

export const TAB = process.env.SHEET_NAME || 'Pedidos';
const Q = `'${TAB.replace(/'/g, "''")}'`;
export const HEAD = ['N.º', 'Fecha', 'Estado', 'Cliente', 'DNI/CE', 'WhatsApp', 'Recibe en', 'Destino', 'Retiro', 'Productos', 'Atendió', 'Voucher', 'Rótulo a imprimir', 'Eliminado', 'ID', 'Datos (no editar)'];
export const ESTADOS = ['Pendiente', 'En agencia', 'En tienda', 'Finalizado'];
export const NAMES = { shalom: 'Shalom', olva: 'Olva', tienda: 'Retiro en tienda', domicilio: 'A domicilio' };
export const fmtN = n => String(n || 0).padStart(6, '0');
export const rng = a => encodeURIComponent(`${Q}!${a}`);
export const RE_ID = /^[a-z0-9]{6,40}$/;
const BLOB_HOST = /^https:\/\/[a-z0-9-]+\.public\.blob\.vercel-storage\.com\//;

export class HttpError extends Error {
  constructor(status, msg) { super(msg); this.status = status; this.expose = true; }
}

export const handler = fn => async (req, res) => {
  try { await fn(req, res); }
  catch (e) {
    console.error(e);
    const status = e.expose && e.status ? e.status : 500;
    res.status(status).json({ error: e.expose ? e.message : 'Error del servidor: ' + (e.message || 'desconocido') });
  }
};

/* ---------- Límite simple de peticiones (por instancia) ---------- */
const hits = new Map();
export function throttle(req, key, max) {
  const ip = String(req.headers['x-forwarded-for'] || req.socket?.remoteAddress || '').split(',')[0].trim();
  const k = key + ':' + ip, now = Date.now();
  const a = (hits.get(k) || []).filter(t => now - t < 60000);
  a.push(now); hits.set(k, a);
  if (hits.size > 5000) hits.clear();
  if (a.length > max) throw new HttpError(429, 'Demasiadas solicitudes, espera un minuto.');
}

/* ---------- Sesiones del equipo ---------- */
const sha = s => crypto.createHash('sha256').update(String(s)).digest();
export const safeEq = (a, b) => crypto.timingSafeEqual(sha(a), sha(b));
const secret = () => process.env.SESSION_SECRET || '';
const sign = p => crypto.createHmac('sha256', secret()).update(p).digest('base64url');

export function teamUsers() {
  return String(process.env.TEAM_USERS || '').split(',').map(x => x.trim()).filter(Boolean).map(x => {
    const i = x.indexOf(':'); return i < 0 ? null : [x.slice(0, i).trim(), x.slice(i + 1)];
  }).filter(Boolean);
}
export function signToken(user) {
  if (!secret()) throw new HttpError(500, 'Falta SESSION_SECRET en Vercel');
  const p = Buffer.from(JSON.stringify({ u: user, e: Date.now() + 7 * 864e5 })).toString('base64url');
  return p + '.' + sign(p);
}
export function requireAuth(req) {
  const h = String(req.headers.authorization || '');
  const t = h.startsWith('Bearer ') ? h.slice(7) : '';
  const [p, s] = t.split('.');
  if (p && s && secret() && safeEq(sign(p), s)) {
    try { const o = JSON.parse(Buffer.from(p, 'base64url').toString()); if (o.e > Date.now()) return o; } catch { /* sigue */ }
  }
  throw new HttpError(401, 'Sesión no válida. Ingresa de nuevo.');
}

/* ---------- Google Sheets ---------- */
let tok = null, tokExp = 0;
async function accessToken() {
  if (tok && Date.now() < tokExp - 60000) return tok;
  const email = process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL;
  const key = String(process.env.GOOGLE_PRIVATE_KEY || '').replace(/\\n/g, '\n');
  if (!email || !key) throw new HttpError(500, 'Faltan GOOGLE_SERVICE_ACCOUNT_EMAIL o GOOGLE_PRIVATE_KEY en Vercel');
  const now = Math.floor(Date.now() / 1000);
  const b = o => Buffer.from(JSON.stringify(o)).toString('base64url');
  const unsigned = b({ alg: 'RS256', typ: 'JWT' }) + '.' + b({ iss: email, scope: 'https://www.googleapis.com/auth/spreadsheets', aud: 'https://oauth2.googleapis.com/token', iat: now, exp: now + 3600 });
  const sig = crypto.createSign('RSA-SHA256').update(unsigned).sign(key).toString('base64url');
  const r = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion: unsigned + '.' + sig })
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new HttpError(500, 'Google rechazó la cuenta de servicio: ' + (j.error_description || j.error || r.status));
  tok = j.access_token; tokExp = Date.now() + (j.expires_in || 3600) * 1000;
  return tok;
}

export async function sheets(path, { method = 'GET', body } = {}) {
  const id = process.env.SHEET_ID;
  if (!id) throw new HttpError(500, 'Falta SHEET_ID en Vercel');
  const t = await accessToken();
  const r = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${id}${path}`, {
    method, headers: { authorization: 'Bearer ' + t, 'content-type': 'application/json' }, body: body ? JSON.stringify(body) : undefined
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) {
    const m = j.error?.message || ('Google Sheets ' + r.status);
    if (r.status === 429) throw new HttpError(503, 'Google Sheets está ocupado, reintenta en unos segundos.');
    if (r.status === 403) throw new HttpError(500, 'Sin permiso en Google Sheets: comparte la hoja con el correo de la cuenta de servicio como Editor. (' + m + ')');
    if (r.status === 404) throw new HttpError(500, 'No se encontró la hoja: revisa SHEET_ID. (' + m + ')');
    throw new HttpError(500, m);
  }
  return j;
}

export async function readRows() {
  const j = await sheets(`/values/${rng('A2:P')}?valueRenderOption=UNFORMATTED_VALUE`);
  return (j.values || []).map((r, i) => ({ row: i + 2, n: r[0], estado: r[2], elim: r[13] === 'ELIMINADO', id: r[14], json: r[15] }));
}
export async function readIds() {
  const j = await sheets(`/values/${rng('O2:O')}?valueRenderOption=UNFORMATTED_VALUE`);
  return (j.values || []).map(r => r[0]);
}
let cache = null, cacheT = 0;
export async function readRowsCached(ms = 3000) {
  if (cache && Date.now() - cacheT < ms) return cache;
  cache = await readRows(); cacheT = Date.now(); return cache;
}
export const bust = () => { cache = null; };

/* ---------- Pedido ⇄ fila ---------- */
const fechaLima = f => { try { return new Date(f).toLocaleString('es-PE', { timeZone: 'America/Lima', hour12: false }); } catch { return ''; } };
const txt = s => "'" + String(s ?? '').replace(/\r?\n/g, ' ');
const img = u => (u && BLOB_HOST.test(u) ? `=IMAGE("${u}",1)` : '');
export const isBlobUrl = u => typeof u === 'string' && BLOB_HOST.test(u);

export function rowValues(o) {
  let js = JSON.stringify(o);
  if (js.length > 49000) { o = { ...o, prod: String(o.prod || '').slice(0, 20000) }; js = JSON.stringify(o); }
  return [
    Number(o.n) > 0 ? Number(o.n) : '', txt(fechaLima(o.f)), o.estado || 'Pendiente', txt(o.nom), txt(o.dni), txt(o.cel),
    NAMES[o.modo] || o.modo || '', txt(o.dest), txt(o.retiro), txt(o.prod), txt(o.at),
    img(o.vou), img(o.rot), o.elim ? 'ELIMINADO' : (o.trash ? 'Papelera' : ''), o.id, js
  ];
}

export function parseRow(r) {
  if (r.elim || !r.json) return null;
  let o; try { o = JSON.parse(r.json); } catch { return null; }
  if (!o || typeof o !== 'object' || !o.id) return null;
  if (typeof r.n === 'number' && r.n > 0) o.n = r.n;
  if (ESTADOS.includes(r.estado)) o.estado = r.estado;
  o.trash = o.trash === true;
  return o;
}

/* ---------- Imágenes (Vercel Blob) ---------- */
export async function uploadImage(dataUrl, name, maxBytes = 1500000) {
  const m = /^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$/.exec(String(dataUrl || ''));
  if (!m) throw new HttpError(400, 'Imagen no válida');
  const buf = Buffer.from(m[2], 'base64');
  if (buf.length > maxBytes) throw new HttpError(400, 'La imagen es muy pesada');
  if (!process.env.BLOB_READ_WRITE_TOKEN) throw new HttpError(500, 'Falta conectar Vercel Blob al proyecto (BLOB_READ_WRITE_TOKEN)');
  const { put } = await import('@vercel/blob');
  const ext = m[1] === 'jpeg' ? 'jpg' : m[1];
  const r = await put(`${name}.${ext}`, buf, { access: 'public', contentType: 'image/' + m[1], addRandomSuffix: true, token: process.env.BLOB_READ_WRITE_TOKEN });
  return r.url;
}
