import { handler, HttpError, teamUsers, safeEq, signToken, throttle } from './_lib.js';

export default handler(async (req, res) => {
  if (req.method !== 'POST') throw new HttpError(405, 'Método no permitido');
  throttle(req, 'login', 12);
  const { user = '', pass = '' } = req.body || {};
  const u = String(user).trim(), p = String(pass);
  let ok = false;
  for (const [x, y] of teamUsers()) { if (safeEq(x, u) & safeEq(y, p)) ok = true; }
  if (!ok || !u) { await new Promise(r => setTimeout(r, 700)); throw new HttpError(401, 'Usuario o contraseña incorrectos'); }
  res.json({ token: signToken(u), user: u });
});
