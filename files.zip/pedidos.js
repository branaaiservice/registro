// GET  → (equipo) lista de pedidos leída de Google Sheets
// POST → (público) registra un pedido nuevo: agrega una fila y devuelve el N.º de pedido
import { handler, HttpError, requireAuth, throttle, readRowsCached, readIds, parseRow, rowValues, sheets, rng, bust, NAMES, RE_ID } from './_lib.js';

const str = (v, max) => String(v ?? '').trim().slice(0, max);

export default handler(async (req, res) => {
  if (req.method === 'GET') {
    requireAuth(req);
    const rows = await readRowsCached();
    res.setHeader('Cache-Control', 'no-store');
    res.json({
      pedidos: rows.map(parseRow).filter(Boolean),
      sheetUrl: `https://docs.google.com/spreadsheets/d/${process.env.SHEET_ID}`
    });
    return;
  }
  if (req.method !== 'POST') throw new HttpError(405, 'Método no permitido');
  throttle(req, 'crear', 40);

  const i = (req.body && req.body.order) || {};
  const o = {
    id: str(i.id, 40), n: 0, f: new Date().toISOString(),
    nom: str(i.nom, 200), dni: str(i.dni, 12), cel: str(i.cel, 9),
    modo: str(i.modo, 20), at: str(i.at, 80), atTel: str(i.atTel, 9),
    estado: 'Pendiente', dest: str(i.dest, 600)
  };
  if (i.retiro) o.retiro = str(i.retiro, 200);
  if (i.agN) o.agN = str(i.agN, 120);
  if (!RE_ID.test(o.id)) throw new HttpError(400, 'Pedido no válido (id)');
  if (!o.nom) throw new HttpError(400, 'Falta el nombre');
  if (!/^[A-Za-z0-9]{8,12}$/.test(o.dni)) throw new HttpError(400, 'Revisa el DNI o CE');
  if (!/^[0-9]{9}$/.test(o.cel)) throw new HttpError(400, 'El WhatsApp debe tener 9 dígitos');
  if (!NAMES[o.modo]) throw new HttpError(400, 'Modo de entrega no válido');
  if (!o.dest) throw new HttpError(400, 'Falta el destino');

  // Si este pedido ya se guardó (reintento), devolvemos su N.º sin duplicar la fila.
  const ids = await readIds();
  const prev = ids.indexOf(o.id);
  if (prev >= 0) {
    const g = await sheets(`/values/${rng('A' + (prev + 2))}?valueRenderOption=UNFORMATTED_VALUE`);
    res.json({ n: Number(g.values?.[0]?.[0]) || 0, dup: true });
    return;
  }

  // Cada fila nueva recibe su propia posición: N.º de pedido = fila − 1 (único aunque lleguen varios a la vez).
  const vals = rowValues(o); vals[0] = '=ROW()-1';
  const a = await sheets(`/values/${rng('A:P')}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`, { method: 'POST', body: { values: [vals] } });
  const m = /!A(\d+)/.exec(a.updates?.updatedRange || '');
  const row = m ? Number(m[1]) : 0;
  if (row < 2) throw new HttpError(500, 'La hoja no está preparada: entra al panel y pulsa «Preparar hoja».');
  o.n = row - 1;
  await sheets(`/values/${rng(`A${row}:P${row}`)}?valueInputOption=USER_ENTERED`, { method: 'PUT', body: { values: [rowValues(o)] } });
  bust();
  res.json({ n: o.n });
});
