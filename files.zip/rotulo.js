// POST (público) {id, n, png}: sube la imagen del rótulo y la coloca en la fila del pedido.
import { handler, HttpError, throttle, readRows, rowValues, sheets, rng, bust, uploadImage, fmtN, RE_ID } from './_lib.js';

export default handler(async (req, res) => {
  if (req.method !== 'POST') throw new HttpError(405, 'Método no permitido');
  throttle(req, 'rotulo', 60);
  const { id, n, png } = req.body || {};
  if (!RE_ID.test(String(id || ''))) throw new HttpError(400, 'Pedido no válido');
  if (typeof png !== 'string' || !png.startsWith('data:image/png;base64,') || png.length > 800000) throw new HttpError(400, 'Imagen del rótulo no válida');

  const r = (await readRows()).find(x => x.id === id);
  if (!r) throw new HttpError(404, 'Pedido no encontrado');
  if (Number(r.n) !== Number(n)) throw new HttpError(409, 'El N.º no coincide');
  let o; try { o = JSON.parse(r.json); } catch { throw new HttpError(409, 'Fila dañada'); }
  if (o.rot) throw new HttpError(409, 'Este pedido ya tiene rótulo');

  o.rot = await uploadImage(png, `rotulos/${fmtN(r.n)}-${id}`, 600000);
  const v = rowValues(o);
  await sheets('/values:batchUpdate', {
    method: 'POST',
    body: { valueInputOption: 'USER_ENTERED', data: [
      { range: decodeURIComponent(rng("M" + r.row)), values: [[v[12]]] },
      { range: decodeURIComponent(rng('P' + r.row)), values: [[v[15]]] }
    ] }
  });
  bust();
  res.json({ ok: true, rot: o.rot });
});
