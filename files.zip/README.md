# Registro de pedidos – Brana (GitHub + Vercel + Google Sheets)

Formulario web para registrar pedidos. **Cada pedido, venga del link que venga, se guarda como una fila en un solo Google Sheet**, junto con la **imagen del rótulo a imprimir**. El panel del equipo lee esa misma hoja y se actualiza solo (cada 8 segundos).

```
Cliente / equipo ──► Vercel (public/index.html + api/*) ──► Google Sheets  (una fila por pedido)
                                      └────────────────► Vercel Blob     (imágenes: rótulo y voucher)
GitHub ──(cada push)──► Vercel despliega solo
```

## Archivos del repositorio

| Archivo | Para qué sirve |
|---|---|
| `public/index.html` | La aplicación (formulario público + panel del equipo) |
| `api/_lib.js` | Utilidades: conexión con Google Sheets, sesiones, subida de imágenes |
| `api/pedidos.js` | Registra pedidos nuevos (público) y los lista (equipo) |
| `api/rotulo.js` | Coloca la imagen del rótulo en la fila del pedido |
| `api/guardar.js` | Guarda cambios del equipo (estado, productos, voucher, papelera) |
| `api/login.js` | Acceso del equipo |
| `api/setup.js` | Prepara la hoja (encabezados, anchos, altura para imágenes) |
| `package.json`, `vercel.json` | Configuración del proyecto |
| `.env.example` | Lista de variables que debes crear en Vercel |
| `.gitignore` | Evita subir claves a GitHub |

## Paso 1 · Google Sheets y cuenta de servicio (10 min)
1. Crea un Google Sheet vacío (ej. «Pedidos Brana») y copia su **ID** (parte de la URL entre `/d/` y `/edit`).
2. Entra a https://console.cloud.google.com → crea un proyecto → **APIs y servicios → Biblioteca → Google Sheets API → Habilitar**.
3. **IAM y administración → Cuentas de servicio → Crear cuenta de servicio** (cualquier nombre).
4. Dentro de la cuenta: **Claves → Agregar clave → JSON**. Se descarga un archivo; de él necesitas `client_email` y `private_key`.
5. En tu Google Sheet pulsa **Compartir** y agrega el `client_email` como **Editor**.

## Paso 2 · Subir a GitHub
1. Crea un repositorio nuevo en GitHub (privado recomendado).
2. Sube **todo el contenido de esta carpeta** (respetando las carpetas `api/` y `public/`).
   - Web: *Add file → Upload files*, arrastrando carpetas y archivos.
   - O por terminal: `git init && git add . && git commit -m "Pedidos Brana" && git branch -M main && git remote add origin <URL> && git push -u origin main`.

## Paso 3 · Conectar con Vercel
1. En https://vercel.com → **Add New → Project → Import** tu repositorio de GitHub. No cambies nada del build (el `vercel.json` ya lo configura).
2. En el proyecto: **Storage → Create Database → Blob** → elige almacenamiento **Público** → conéctalo al proyecto. Vercel crea solo `BLOB_READ_WRITE_TOKEN`.
3. **Settings → Environment Variables**: crea estas variables (puedes guiarte con `.env.example`):

| Variable | Valor |
|---|---|
| `SHEET_ID` | ID de tu Google Sheet |
| `SHEET_NAME` | `Pedidos` |
| `GOOGLE_SERVICE_ACCOUNT_EMAIL` | `client_email` del JSON |
| `GOOGLE_PRIVATE_KEY` | `private_key` del JSON, tal cual (con los `\n`) |
| `TEAM_USERS` | `maria:ClaveSegura1,juan:OtraClave2` (usuario:clave, sin comas dentro de la clave) |
| `SESSION_SECRET` | Un texto largo y aleatorio (32+ caracteres) |

4. **Deployments → Redeploy** para que tome las variables.

## Paso 4 · Preparar la hoja (una sola vez)
1. Abre tu link de Vercel → pestaña **Pedidos** → ingresa con un usuario de `TEAM_USERS`.
2. Pulsa **Preparar hoja**. Crea la pestaña, los encabezados y deja las filas con altura para ver las imágenes.
3. Pulsa **Abrir Google Sheets** para ver la hoja. Registra un pedido de prueba para comprobar que aparece la fila con el rótulo.

## Cómo funciona
- **Nuevo pedido (público):** el cliente o tu equipo registra el pedido. El servidor agrega una fila y entrega el **N.º de pedido** (= fila − 1, único aunque lleguen varios a la vez). El navegador dibuja el rótulo como imagen PNG (4×2 in, 300 dpi) y la coloca en la columna **Rótulo a imprimir** con `=IMAGE(...)`.
- **Panel del equipo:** lee la hoja cada 8 s y al volver a la pestaña. Los cambios (estado, productos, voucher, papelera) se escriben en la misma fila. Si cambias el **Estado** directamente en el Sheet, también llega a la app.
- **Sin internet:** el pedido queda en el navegador y se reenvía solo.
- **Respaldo del rótulo:** si algún pedido quedó sin imagen, el panel del equipo la genera (de a 3 por vez).

## Columnas de la hoja
N.º · Fecha · Estado · Cliente · DNI/CE · WhatsApp · Recibe en · Destino · Retiro · Productos · Atendió · Voucher (imagen) · Rótulo a imprimir (imagen) · Eliminado · *ID y Datos (ocultas, no editar)*.

## Importante
- **No ordenes, borres ni muevas filas** del Sheet: el N.º de pedido depende de la fila. Para filtrar usa *Datos → Crear un filtro* o una vista de filtro.
- Las filas que borras en la app se marcan **ELIMINADO** (no se borran de la hoja).
- Agencias, hora de corte y «clientes conocidos» siguen guardándose por navegador (no están en la hoja).
- Si el panel ya tenía pedidos guardados en el navegador (versión anterior), se suben solos a la hoja al ingresar con su N.º antiguo. Si prefieres empezar de cero, borra los datos del sitio antes de entrar.
- Capacidad: Google Sheets permite ~60 operaciones por minuto con este método; alcanza para unos 10 pedidos por minuto. Para más volumen conviene una base de datos tradicional.
- Las imágenes (rótulo y voucher) se guardan en Vercel Blob con enlace público difícil de adivinar; el voucher puede mostrar datos de pago, así que comparte la hoja solo con quien corresponda.
- Nunca subas el JSON de la cuenta de servicio a GitHub.

## Trabajar con Claude, GitHub y Vercel
- **Claude (chat)** te sirve para pedir cambios y recibir los archivos actualizados; súbelos al repo.
- **Claude Code** (terminal o app de escritorio) puede editar el repositorio, hacer commit y push directamente: `claude` dentro de la carpeta del proyecto.
- **Vercel despliega solo** cada vez que haces push a `main`. Cada rama/PR genera además un link de prueba.
- En Claude puedes agregar el conector de **Vercel** (Configuración → Conectores) para revisar despliegues y errores desde el chat.

## Probar en tu PC (opcional)
`npm i -g vercel` → `vercel link` → `vercel env pull .env.local` → `vercel dev`.
