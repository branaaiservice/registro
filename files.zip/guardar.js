// POST (equipo) {orders:[...], del:[ids]}: guarda cambios (estado, productos, voucher, papelera...) en Google Sheets.
import { handler, HttpError, requireAuth, readRows, rowValues, sheets, rng, bust, uploadImage, isBlobUrl, fmtN, ESTADOS, NAMES, RE_ID } from './_lib.js';

const MAX_TEXT = 4000;

export default handler(async (req, res) => {
  if (req.method !== 'POST') throw new HttpError(405, 'Método no permitido');
  requireAuth(req);
  const orders = Array.isArray(req.body?.orders) ? req.body.orders.slice(0, 40) : [];
  const del = Array.isArray(req.body?.del) ? req.body.del.slice(0, 200) : [];

  const rows = await readRows();
  const byId = new Map(rows.filter(r => r.id).map(r => [r.id, r]));
  const urls = {}, data = [], add = [];

  for (const raw of orders) {
    if (!raw || !RE_ID.test(String(raw.id || ''))) continue;
    const o = { ...raw }; delete o.prov; delete o.elim;
    if (!ESTADOS.includes(o.estado)) o.estado = 'Pendiente';
    if (!NAMES[o.modo]) throw new HttpError(400, 'Pedido ' + o.id + ': modo no válido');
    for (const k of ['nom', 'dni', 'cel', 'dest', 'retiro', 'at', 'atTel', 'prod', 'agN']) if (o[k] != null) o[k] = String(o[k]).slice(0, MAX_TEXT);
    o.trash = o.trash === true;

    const ex = byId.get(o.id);
    let prev = {}; if (ex?.json) { try { prev = JSON.parse(ex.json); } catch { prev = {}; } }

    // Voucher: si llega como imagen, se sube a Vercel Blob y en la hoja queda la URL.
    if (typeof o.vou === 'string' && o.vou.startsWith('data:')) {
      o.vou = await uploadImage(o.vou, `vouchers/${fmtN(o.n)}-${o.id}`, 700000);
      urls[o.id] = { ...(urls[o.id] || {}), vou: o.vou };
    } else if (o.vou && !isBlobUrl(o.vou)) delete o.vou;
    if (!isBlobUrl(o.rot)) o.rot = prev.rot && isBlobUrl(prev.rot) ? prev.rot : undefined;
    if (!o.rot) delete o.rot;
    if (!o.vou) { delete o.vou; if (ex) urls[o.id] = { ...(urls[o.id] || {}), vou: '' }; }
    urls[o.id] = { ...(urls[o.id] || {}), rot: o.rot || '' };

    if (ex) {
      if (Number(ex.n) > 0) o.n = Number(ex.n);
      data.push({ range: decodeURIComponent(rng(`A${ex.row}:P${ex.row}`)), values: [rowValues(o)] });
    } else add.push(o);
  }
  for (const id of del) {
    const ex = byId.get(String(id));
    if (ex) data.push({ range: decodeURIComponent(rng('N' + ex.row)), values: [['ELIMINADO']] });
  }

  if (data.length) await sheets('/values:batchUpdate', { method: 'POST', body: { valueInputOption: 'USER_ENTERED', data } });
  if (add.length) await sheets(`/values/${rng('A:P')}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`, { method: 'POST', body: { values: add.map(rowValues) } });
  bust();
  res.json({ ok: true, urls });
});
